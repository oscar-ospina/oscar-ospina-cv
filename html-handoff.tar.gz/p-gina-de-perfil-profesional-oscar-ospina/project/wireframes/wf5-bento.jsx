// Wireframe 5: Card-based / bento grid — todo visible al mismo tiempo, tipo dashboard personal

function Wireframe5() {
  const W = 900;
  return (
    <Paper width={W} height={1100}>
      {/* top bar */}
      <div style={{ padding: '18px 32px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 10, height: 10, background: WF.accent, borderRadius: '50%' }} />
          <HandText size={13} style={{ fontFamily: WF.mono }}>oscar.ospina</HandText>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <SketchBtn width={80} height={28}>ES / EN</SketchBtn>
          <SketchBtn primary width={100} height={28}>Contactar</SketchBtn>
        </div>
      </div>

      {/* BENTO GRID */}
      <div style={{
        padding: '8px 32px 32px',
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gridAutoRows: '140px',
        gap: 14,
      }}>
        {/* HERO card — span 2x2 */}
        <BentoCard span="2 / span 2" row="span 2" accent>
          <div style={{ padding: 24, height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <div>
              <HandText size={10} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>HOLA, SOY</HandText>
              <HandTitle size={56} style={{ lineHeight: 0.95 }}>Oscar<br/>Ospina</HandTitle>
              <Squiggle width={180} />
              <div style={{ height: 8 }} />
              <HandText size={16} color={WF.ink}>[ Rol profesional ]</HandText>
              <div style={{ height: 8 }} />
              <FakeText lines={2} lastWidth="60%" />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <SketchBtn primary width={120}>Ver CV</SketchBtn>
              <SketchBtn width={120}>Escribir</SketchBtn>
            </div>
          </div>
        </BentoCard>

        {/* Foto */}
        <BentoCard row="span 2">
          <ImgPlaceholder height="100%" label="FOTO" seed={60} />
        </BentoCard>

        {/* Now */}
        <BentoCard>
          <div style={{ padding: 16 }}>
            <HandText size={10} color={WF.accent} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>● AHORA</HandText>
            <div style={{ height: 6 }} />
            <HandText size={13} style={{ fontWeight: 600 }}>[ Cargo actual ]</HandText>
            <HandText size={11} color={WF.inkFaint}>Empresa · desde 2024</HandText>
          </div>
        </BentoCard>

        {/* Ubicación */}
        <BentoCard>
          <div style={{ padding: 16 }}>
            <HandText size={10} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>UBICACIÓN</HandText>
            <div style={{ height: 6 }} />
            <HandTitle size={22}>Ciudad,<br/>País</HandTitle>
          </div>
        </BentoCard>

        {/* Años experiencia — número grande */}
        <BentoCard>
          <div style={{ padding: 16, height: '100%', display: 'flex', flexDirection: 'column', justifyContent: 'space-between' }}>
            <HandText size={10} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>EXPERIENCIA</HandText>
            <HandTitle size={56} color={WF.accent} style={{ lineHeight: 0.8 }}>10<span style={{ fontSize: 24, color: WF.ink }}>años</span></HandTitle>
          </div>
        </BentoCard>

        {/* Skills compactas — span 2 */}
        <BentoCard span="span 2">
          <div style={{ padding: 16 }}>
            <HandText size={10} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>HABILIDADES</HandText>
            <div style={{ height: 8 }} />
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
              {Array.from({ length: 8 }).map((_, i) => <Tag key={i} accent={i % 3 === 0}>skill</Tag>)}
            </div>
          </div>
        </BentoCard>

        {/* Links sociales — span 2 */}
        <BentoCard span="span 2">
          <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 8, height: '100%', justifyContent: 'center' }}>
            {['✦ LinkedIn', '✦ GitHub', '✦ email@ejemplo'].map((s, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', borderBottom: `1px dashed ${WF.inkFaint}`, paddingBottom: 4 }}>
                <HandText size={13} style={{ fontWeight: 500 }}>{s}</HandText>
                <HandText size={13} color={WF.inkFaint}>→</HandText>
              </div>
            ))}
          </div>
        </BentoCard>

        {/* Proyectos — span 4 */}
        <BentoCard span="span 4" row="span 2">
          <div style={{ padding: 20 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
              <HandTitle size={24}>Proyectos recientes</HandTitle>
              <HandText size={12} color={WF.accent}>ver todos →</HandText>
            </div>
            <div style={{ height: 12 }} />
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
              {[1, 2, 3].map((i) => (
                <div key={i}>
                  <ImgPlaceholder height={100} label={`P${i}`} seed={i + 70} />
                  <div style={{ height: 6 }} />
                  <HandText size={12} style={{ fontWeight: 600 }}>Proyecto {i}</HandText>
                  <FakeText lines={1} lastWidth="70%" />
                </div>
              ))}
            </div>
          </div>
        </BentoCard>

        {/* Experiencia timeline compacto — span 4 */}
        <BentoCard span="span 4" row="span 2">
          <div style={{ padding: 20 }}>
            <HandTitle size={24}>Trayectoria</HandTitle>
            <div style={{ height: 12 }} />
            <div style={{ display: 'flex', gap: 14, alignItems: 'stretch' }}>
              {[1, 2, 3, 4].map((i) => (
                <div key={i} style={{ flex: 1, borderLeft: `2px solid ${i === 1 ? WF.accent : WF.ink}`, paddingLeft: 10 }}>
                  <HandText size={10} color={WF.inkFaint} style={{ fontFamily: WF.mono }}>2026 — 2024</HandText>
                  <HandText size={13} style={{ fontWeight: 700 }}>[ Cargo ]</HandText>
                  <HandText size={11} color={WF.accent}>Empresa</HandText>
                  <div style={{ height: 6 }} />
                  <FakeText lines={2} lastWidth="80%" lineHeight={6} gap={3} />
                </div>
              ))}
            </div>
          </div>
        </BentoCard>
      </div>

      <Annotation style={{ position: 'absolute', top: 180, right: -20, transform: 'rotate(8deg)', maxWidth: 120 }}>
        bento grid — todo visible
      </Annotation>
    </Paper>
  );
}

function BentoCard({ children, span = 'span 1', row = 'span 1', accent = false }) {
  return (
    <div style={{
      gridColumn: span, gridRow: row,
      border: `1.5px solid ${WF.ink}`,
      background: accent ? WF.accentSoft : 'transparent',
      borderRadius: 6,
      overflow: 'hidden',
      position: 'relative',
    }}>
      {children}
    </div>
  );
}

window.Wireframe5 = Wireframe5;
