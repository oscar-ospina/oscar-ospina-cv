// Wireframe 1: Single-page scroll clásico
// Hero centrado → sobre mí → experiencia timeline → proyectos grid → skills → contacto

function Wireframe1() {
  const W = 720;
  return (
    <Paper width={W} height={1800} style={{ fontFamily: WF.hand }}>
      {/* NAV */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '20px 40px', borderBottom: `1px dashed ${WF.inkFaint}` }}>
        <HandTitle size={20}>Oscar Ospina</HandTitle>
        <div style={{ display: 'flex', gap: 20, fontFamily: WF.hand, fontSize: 13 }}>
          <span>Sobre</span><span>Experiencia</span><span>Proyectos</span><span>Contacto</span>
        </div>
      </div>

      {/* HERO */}
      <div style={{ padding: '60px 40px 40px', textAlign: 'center', position: 'relative' }}>
        <Avatar size={100} />
        <div style={{ height: 16 }} />
        <HandTitle size={52}>Oscar Ospina</HandTitle>
        <div style={{ display: 'inline-block', marginTop: 8 }}>
          <Squiggle width={220} />
        </div>
        <div style={{ height: 8 }} />
        <HandText size={18} color={WF.ink}>[ Rol profesional / Tagline ]</HandText>
        <div style={{ height: 16 }} />
        <div style={{ maxWidth: 440, margin: '0 auto' }}>
          <FakeText lines={2} lastWidth="60%" />
        </div>
        <div style={{ height: 24 }} />
        <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
          <SketchBtn primary width={140}>Contáctame</SketchBtn>
          <SketchBtn width={140}>Descargar CV</SketchBtn>
        </div>
        <Annotation style={{ position: 'absolute', top: 80, right: 30, transform: 'rotate(6deg)' }}>foto + hook</Annotation>
      </div>

      <div style={{ padding: '0 40px' }}><SketchLine length={W - 80} seed={2} /></div>

      {/* SOBRE MÍ */}
      <div style={{ padding: '40px 40px' }}>
        <HandTitle size={28}>01 · Sobre mí</HandTitle>
        <div style={{ height: 16 }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
          <div><FakeText lines={6} /></div>
          <div><FakeText lines={6} /></div>
        </div>
      </div>

      {/* EXPERIENCIA TIMELINE */}
      <div style={{ padding: '40px 40px', position: 'relative' }}>
        <HandTitle size={28}>02 · Experiencia</HandTitle>
        <div style={{ height: 20 }} />
        {[0, 1, 2, 3].map((i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '120px 24px 1fr', gap: 16, marginBottom: 24, alignItems: 'flex-start' }}>
            <div>
              <HandText size={14} color={WF.ink} style={{ fontWeight: 600 }}>2022 — Hoy</HandText>
              <HandText size={11} color={WF.inkFaint}>Ciudad</HandText>
            </div>
            <div style={{ position: 'relative', height: '100%', display: 'flex', justifyContent: 'center' }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: WF.ink, marginTop: 4 }} />
              {i < 3 && <div style={{ position: 'absolute', top: 16, bottom: -24, width: 1, borderLeft: `1.5px dashed ${WF.inkFaint}` }} />}
            </div>
            <div>
              <HandText size={15} color={WF.ink} style={{ fontWeight: 600 }}>[ Cargo ] · [ Empresa ]</HandText>
              <div style={{ height: 6 }} />
              <FakeText lines={2} lastWidth="65%" />
              <div style={{ display: 'flex', gap: 6, marginTop: 8, flexWrap: 'wrap' }}>
                <Tag>skill</Tag><Tag>skill</Tag><Tag accent>logro clave</Tag>
              </div>
            </div>
          </div>
        ))}
        <Annotation style={{ position: 'absolute', right: 10, top: 100, transform: 'rotate(-4deg)', maxWidth: 110, textAlign: 'center' }} side="left">línea de tiempo vertical</Annotation>
      </div>

      {/* PROYECTOS GRID */}
      <div style={{ padding: '40px 40px', background: WF.accentSoft }}>
        <HandTitle size={28}>03 · Proyectos destacados</HandTitle>
        <div style={{ height: 16 }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {[1, 2, 3, 4].map((i) => (
            <div key={i}>
              <ImgPlaceholder height={140} label={`PROYECTO ${i}`} seed={i + 10} />
              <div style={{ height: 8 }} />
              <HandText size={14} color={WF.ink} style={{ fontWeight: 600 }}>Nombre del proyecto {i}</HandText>
              <FakeText lines={2} lastWidth="50%" />
            </div>
          ))}
        </div>
      </div>

      {/* SKILLS */}
      <div style={{ padding: '40px 40px' }}>
        <HandTitle size={28}>04 · Habilidades</HandTitle>
        <div style={{ height: 16 }} />
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
          {['skill 1', 'skill 2', 'skill 3', 'skill 4', 'skill 5', 'skill 6', 'skill 7', 'skill 8', 'skill 9'].map((s, i) => (
            <Tag key={i} accent={i % 3 === 0}>{s}</Tag>
          ))}
        </div>
      </div>

      {/* CONTACTO */}
      <div style={{ padding: '40px 40px', textAlign: 'center', borderTop: `1px dashed ${WF.inkFaint}` }}>
        <HandTitle size={36}>¿Trabajamos juntos?</HandTitle>
        <div style={{ height: 12 }} />
        <HandText size={15}>email · LinkedIn · GitHub</HandText>
        <div style={{ height: 20 }} />
        <SketchBtn primary width={160}>Enviar mensaje</SketchBtn>
      </div>
    </Paper>
  );
}

window.Wireframe1 = Wireframe1;
