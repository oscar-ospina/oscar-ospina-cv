// Wireframe 4: Editorial / tipo revista — tipografía grande, asimétrico, mucho whitespace

function Wireframe4() {
  const W = 900;
  return (
    <Paper width={W} height={1600}>
      {/* masthead */}
      <div style={{ padding: '20px 50px', display: 'flex', justifyContent: 'space-between', borderBottom: `2px solid ${WF.ink}`, alignItems: 'baseline' }}>
        <HandText size={11} color={WF.inkSoft} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>VOL. 01 · PERFIL · 2026</HandText>
        <HandText size={11} color={WF.inkSoft} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>OO — OSPINA</HandText>
        <HandText size={11} color={WF.inkSoft} style={{ fontFamily: WF.mono }}>ES / EN</HandText>
      </div>

      {/* HERO ENORME */}
      <div style={{ padding: '60px 50px 40px', position: 'relative' }}>
        <HandText size={12} color={WF.accent} style={{ fontFamily: WF.mono, letterSpacing: 3, marginBottom: 12 }}>— PERFIL N° 01</HandText>
        <div style={{ fontFamily: WF.display, fontSize: 140, fontWeight: 700, lineHeight: 0.88, letterSpacing: -2 }}>
          Oscar,<br/>
          <span style={{ fontStyle: 'italic', color: WF.accent }}>el que</span><br/>
          construye.
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 40, marginTop: 40, alignItems: 'flex-start' }}>
          <div>
            <FakeText lines={3} lastWidth="70%" />
          </div>
          <div style={{ borderLeft: `3px solid ${WF.ink}`, paddingLeft: 16 }}>
            <HandText size={11} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2, marginBottom: 4 }}>EN ESTA EDICIÓN</HandText>
            <HandText size={13}>→ Carrera en 4 capítulos</HandText>
            <HandText size={13}>→ 3 proyectos bandera</HandText>
            <HandText size={13}>→ Lo que viene</HandText>
          </div>
        </div>
        <Annotation style={{ position: 'absolute', top: 70, right: 40, transform: 'rotate(-6deg)' }}>tipografía GRANDE</Annotation>
      </div>

      {/* full-bleed imagen */}
      <div style={{ padding: '0 50px' }}>
        <ImgPlaceholder height={280} label="IMAGEN EDITORIAL — FOTO PROFESIONAL O ESCENA DE TRABAJO" seed={44} />
      </div>

      {/* DROP CAP INTRO */}
      <div style={{ padding: '50px 50px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40 }}>
        <div>
          <HandText size={11} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2, marginBottom: 10 }}>CAP. 01 — ORIGEN</HandText>
          <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
            <div style={{ fontFamily: WF.display, fontSize: 96, fontWeight: 700, lineHeight: 0.8, color: WF.accent }}>C</div>
            <div style={{ paddingTop: 8 }}>
              <FakeText lines={8} lastWidth="60%" />
            </div>
          </div>
        </div>
        <div>
          <HandText size={11} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2, marginBottom: 10 }}>CAP. 02 — OFICIO</HandText>
          <FakeText lines={9} lastWidth="55%" />
        </div>
      </div>

      {/* pull quote */}
      <div style={{ padding: '0 50px 50px' }}>
        <div style={{ borderTop: `2px solid ${WF.ink}`, borderBottom: `2px solid ${WF.ink}`, padding: '32px 0', textAlign: 'center' }}>
          <HandTitle size={44} style={{ fontStyle: 'italic', maxWidth: 700, margin: '0 auto', lineHeight: 1.1 }}>
            "Una cita memorable sobre tu filosofía de trabajo."
          </HandTitle>
          <div style={{ height: 10 }} />
          <HandText size={12} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>— O.O.</HandText>
        </div>
      </div>

      {/* proyectos tipo reportaje */}
      <div style={{ padding: '20px 50px' }}>
        <HandText size={11} color={WF.inkFaint} style={{ fontFamily: WF.mono, letterSpacing: 2, marginBottom: 10 }}>CAP. 03 — OBRAS</HandText>
        <HandTitle size={52}>Tres proyectos</HandTitle>
        <div style={{ height: 24 }} />
        {[1, 2, 3].map((i) => (
          <div key={i} style={{
            display: 'grid',
            gridTemplateColumns: i % 2 ? '1fr 1.5fr' : '1.5fr 1fr',
            gap: 30, marginBottom: 36, alignItems: 'center',
          }}>
            {i % 2 ? (
              <>
                <ImgPlaceholder height={200} label={`PROY ${i}`} seed={i + 50} />
                <div>
                  <HandText size={11} color={WF.accent} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>N° 0{i}</HandText>
                  <HandTitle size={32}>Título del proyecto {i}</HandTitle>
                  <div style={{ height: 8 }} />
                  <FakeText lines={3} lastWidth="65%" />
                </div>
              </>
            ) : (
              <>
                <div>
                  <HandText size={11} color={WF.accent} style={{ fontFamily: WF.mono, letterSpacing: 2 }}>N° 0{i}</HandText>
                  <HandTitle size={32}>Título del proyecto {i}</HandTitle>
                  <div style={{ height: 8 }} />
                  <FakeText lines={3} lastWidth="65%" />
                </div>
                <ImgPlaceholder height={200} label={`PROY ${i}`} seed={i + 50} />
              </>
            )}
          </div>
        ))}
      </div>

      {/* footer/contact */}
      <div style={{ padding: '40px 50px', borderTop: `2px solid ${WF.ink}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <HandTitle size={28}>Fin. Próximo capítulo:</HandTitle>
        <SketchBtn primary width={160}>escribir →</SketchBtn>
      </div>
    </Paper>
  );
}

window.Wireframe4 = Wireframe4;
