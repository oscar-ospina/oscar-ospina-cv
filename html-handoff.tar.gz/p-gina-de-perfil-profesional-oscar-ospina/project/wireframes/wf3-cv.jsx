// Wireframe 3: Estilo CV / hoja de vida — todo en una vista, denso, imprimible

function Wireframe3() {
  const W = 620;
  return (
    <Paper width={W} height={880} style={{ padding: 0 }}>
      {/* HEADER CV */}
      <div style={{ padding: '28px 36px 20px', borderBottom: `2px solid ${WF.ink}`, display: 'flex', gap: 20, alignItems: 'flex-start' }}>
        <div style={{ flex: 1 }}>
          <HandTitle size={36}>OSCAR OSPINA</HandTitle>
          <HandText size={13} color={WF.accent} style={{ fontWeight: 600, letterSpacing: 2, fontFamily: WF.mono }}>[ ROL PROFESIONAL ]</HandText>
          <div style={{ height: 10 }} />
          <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
            <HandText size={11} color={WF.inkSoft}>✉ email@ejemplo</HandText>
            <HandText size={11} color={WF.inkSoft}>☏ +57 ...</HandText>
            <HandText size={11} color={WF.inkSoft}>⚲ Ciudad</HandText>
            <HandText size={11} color={WF.inkSoft}>⎘ linkedin/oscar</HandText>
          </div>
        </div>
        <Avatar size={70} />
      </div>

      {/* BODY 2 COLS */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.8fr', gap: 24, padding: '20px 36px' }}>
        {/* LEFT COL */}
        <div>
          <CVBlock title="PERFIL">
            <FakeText lines={4} lastWidth="80%" lineHeight={7} gap={4} />
          </CVBlock>

          <CVBlock title="CONTACTO">
            <FakeText lines={3} lastWidth="70%" lineHeight={7} gap={4} />
          </CVBlock>

          <CVBlock title="EDUCACIÓN">
            {[1, 2].map((i) => (
              <div key={i} style={{ marginBottom: 10 }}>
                <HandText size={12} color={WF.ink} style={{ fontWeight: 600 }}>[ Título {i} ]</HandText>
                <HandText size={11} color={WF.inkFaint}>Universidad · 2018</HandText>
              </div>
            ))}
          </CVBlock>

          <CVBlock title="SKILLS">
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4 }}>
              {Array.from({ length: 10 }).map((_, i) => <Tag key={i} accent={i % 4 === 0}>skill</Tag>)}
            </div>
          </CVBlock>

          <CVBlock title="IDIOMAS">
            <HandText size={12}>Español — Nativo</HandText>
            <HandText size={12}>Inglés — C1</HandText>
          </CVBlock>
        </div>

        {/* RIGHT COL */}
        <div>
          <CVBlock title="EXPERIENCIA">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} style={{ marginBottom: 14 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                  <HandText size={13} color={WF.ink} style={{ fontWeight: 700 }}>[ Cargo ]</HandText>
                  <HandText size={10} color={WF.inkFaint} style={{ fontFamily: WF.mono }}>2024 — Hoy</HandText>
                </div>
                <HandText size={11} color={WF.accent}>Empresa · Ciudad</HandText>
                <div style={{ height: 4 }} />
                <FakeText lines={2} lastWidth="70%" lineHeight={6} gap={3} />
                <ul style={{ margin: '4px 0 0 14px', padding: 0, fontFamily: WF.hand, fontSize: 11, color: WF.inkSoft }}>
                  <li>Logro / responsabilidad concreta</li>
                  <li>Otro logro con métrica ↗</li>
                </ul>
              </div>
            ))}
          </CVBlock>

          <CVBlock title="PROYECTOS DESTACADOS">
            {[1, 2].map((i) => (
              <div key={i} style={{ marginBottom: 8, display: 'flex', gap: 10 }}>
                <div style={{ width: 4, background: WF.accent, flexShrink: 0 }} />
                <div>
                  <HandText size={12} color={WF.ink} style={{ fontWeight: 600 }}>Proyecto {i}</HandText>
                  <FakeText lines={1} lastWidth="85%" lineHeight={6} />
                </div>
              </div>
            ))}
          </CVBlock>

          <CVBlock title="CERTIFICACIONES">
            <FakeText lines={2} lastWidth="60%" lineHeight={6} gap={3} />
          </CVBlock>
        </div>
      </div>

      {/* annotation */}
      <Annotation style={{ position: 'absolute', bottom: 20, right: 20, transform: 'rotate(-3deg)', maxWidth: 120, textAlign: 'center' }}>
        formato imprimible, una vista
      </Annotation>
    </Paper>
  );
}

function CVBlock({ title, children }) {
  return (
    <div style={{ marginBottom: 18 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 8 }}>
        <HandText size={11} color={WF.ink} style={{ fontFamily: WF.mono, fontWeight: 700, letterSpacing: 1.5 }}>{title}</HandText>
        <div style={{ flex: 1, height: 1, background: WF.ink }} />
      </div>
      {children}
    </div>
  );
}

window.Wireframe3 = Wireframe3;
