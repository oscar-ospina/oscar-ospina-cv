// Wireframe 2: Sidebar fija + contenido scrollable
// Sidebar izquierda con identidad y nav, contenido denso a la derecha

function Wireframe2() {
  const W = 860;
  const SIDE = 260;
  return (
    <Paper width={W} height={1400} style={{ display: 'flex' }}>
      {/* SIDEBAR */}
      <div style={{
        width: SIDE, borderRight: `1.5px solid ${WF.ink}`,
        padding: '32px 24px', display: 'flex', flexDirection: 'column',
        gap: 20, position: 'relative',
      }}>
        <Avatar size={80} />
        <div>
          <HandTitle size={26}>Oscar Ospina</HandTitle>
          <div style={{ marginTop: 4 }}><Squiggle width={120} /></div>
          <HandText size={13}>[ Rol / título ]</HandText>
        </div>

        <div>
          <FakeText lines={3} lastWidth="80%" />
        </div>

        <SketchLine length={SIDE - 48} seed={3} />

        {/* nav */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {['Sobre mí', 'Experiencia', 'Educación', 'Proyectos', 'Skills', 'Publicaciones', 'Contacto'].map((n, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontFamily: WF.mono, fontSize: 10, color: WF.inkFaint, width: 24 }}>{String(i + 1).padStart(2, '0')}</span>
              <HandText size={14} color={i === 1 ? WF.accent : WF.ink} style={{ fontWeight: i === 1 ? 700 : 400 }}>{n}</HandText>
              {i === 1 && <span style={{ color: WF.accent }}>●</span>}
            </div>
          ))}
        </div>

        <SketchLine length={SIDE - 48} seed={4} />

        {/* contact mini */}
        <div>
          <HandText size={11} color={WF.inkFaint}>CONTACTO</HandText>
          <div style={{ height: 6 }} />
          <FakeText lines={3} lastWidth="70%" />
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 'auto' }}>
          <SketchBtn width={90} height={30}>LinkedIn</SketchBtn>
          <SketchBtn width={90} height={30}>GitHub</SketchBtn>
        </div>

        <Annotation style={{ position: 'absolute', top: 20, right: -90, transform: 'rotate(4deg)', width: 80 }}>sidebar fija</Annotation>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ flex: 1, padding: '32px 40px', overflow: 'hidden' }}>
        {/* header sticky */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
          <HandText size={11} color={WF.inkFaint}>02 / EXPERIENCIA</HandText>
          <HandText size={11} color={WF.inkFaint}>última actualización: 2026</HandText>
        </div>

        <HandTitle size={42}>Experiencia profesional</HandTitle>
        <div style={{ height: 8 }} />
        <div style={{ maxWidth: 480 }}>
          <FakeText lines={2} lastWidth="60%" />
        </div>

        <div style={{ height: 32 }} />

        {/* cada experiencia como fila completa */}
        {[1, 2, 3, 4].map((i) => (
          <div key={i} style={{ marginBottom: 28, paddingBottom: 24, borderBottom: `1px dashed ${WF.inkFaint}` }}>
            <div style={{ display: 'grid', gridTemplateColumns: '140px 1fr auto', gap: 20, alignItems: 'flex-start' }}>
              <HandText size={13} color={WF.inkFaint} style={{ fontFamily: WF.mono }}>2024 — 2026</HandText>
              <div>
                <HandText size={18} color={WF.ink} style={{ fontWeight: 700 }}>[ Cargo senior ]</HandText>
                <HandText size={14} color={WF.accent}>[ Empresa · Ciudad ]</HandText>
                <div style={{ height: 10 }} />
                <FakeText lines={3} lastWidth="55%" />
                <div style={{ display: 'flex', gap: 6, marginTop: 10, flexWrap: 'wrap' }}>
                  <Tag>tech</Tag><Tag>tech</Tag><Tag>tech</Tag><Tag accent>resultado</Tag>
                </div>
              </div>
              <ImgPlaceholder width={90} height={90} label="LOGO" seed={i + 20} />
            </div>
          </div>
        ))}

        {/* proyectos compactos */}
        <div style={{ height: 20 }} />
        <HandTitle size={24}>Proyectos relacionados</HandTitle>
        <div style={{ height: 12 }} />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12 }}>
          {[1, 2, 3].map((i) => (
            <SketchBox key={i} height={100} seed={i + 30} style={{ padding: 12 }}>
              <div style={{ padding: 12 }}>
                <HandText size={13} color={WF.ink} style={{ fontWeight: 600 }}>Proyecto {i}</HandText>
                <FakeText lines={2} lastWidth="60%" />
              </div>
            </SketchBox>
          ))}
        </div>
      </div>
    </Paper>
  );
}

window.Wireframe2 = Wireframe2;
