// Sketchy wireframe primitives — handwritten, lo-fi, b&w + 1 accent
// Use these to build wireframes that feel hand-drawn but readable.

const WF = {
  paper: '#FAF7F0',
  ink: '#1a1a1a',
  inkSoft: '#3d3d3d',
  inkFaint: '#9a958a',
  accent: 'oklch(0.55 0.15 240)', // wireframe blue
  accentSoft: 'oklch(0.92 0.04 240)',
  hand: '"Kalam", "Comic Sans MS", cursive',
  display: '"Caveat", "Marker Felt", cursive',
  mono: '"JetBrains Mono", "Courier New", monospace',
};

// Wobbly box drawn with SVG so it feels hand-sketched.
function SketchBox({ width = '100%', height = 100, fill = 'transparent', stroke = WF.ink, strokeWidth = 1.5, children, style = {}, dashed = false, seed = 1 }) {
  // generate a wobbly rectangle path
  const w = typeof width === 'number' ? width : 300;
  const h = height;
  const wob = (i) => (Math.sin(seed * i * 1.7) * 1.2);
  const path = `
    M ${2 + wob(1)} ${2 + wob(2)}
    L ${w - 2 + wob(3)} ${1 + wob(4)}
    L ${w - 1 + wob(5)} ${h - 2 + wob(6)}
    L ${1 + wob(7)} ${h - 1 + wob(8)}
    Z
  `;
  return (
    <div style={{ position: 'relative', width, height, ...style }}>
      <svg width="100%" height="100%" viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }}>
        <path d={path} fill={fill} stroke={stroke} strokeWidth={strokeWidth} strokeLinejoin="round" strokeLinecap="round" strokeDasharray={dashed ? '5 4' : '0'} />
      </svg>
      <div style={{ position: 'relative', width: '100%', height: '100%' }}>{children}</div>
    </div>
  );
}

// Hand-drawn line (wobbly)
function SketchLine({ width = '100%', length = 200, stroke = WF.ink, strokeWidth = 1.5, style = {}, seed = 1 }) {
  const w = length;
  const path = `M 0 ${4 + Math.sin(seed) * 1} Q ${w * 0.33} ${2 + Math.sin(seed * 2) * 2}, ${w * 0.5} ${4 + Math.sin(seed * 3) * 1.5} T ${w} ${3 + Math.sin(seed * 5) * 1.5}`;
  return (
    <svg width={width} height="8" viewBox={`0 0 ${w} 8`} preserveAspectRatio="none" style={style}>
      <path d={path} fill="none" stroke={stroke} strokeWidth={strokeWidth} strokeLinecap="round" />
    </svg>
  );
}

// Squiggly underline for emphasis
function Squiggle({ width = 80, color = WF.accent, style = {} }) {
  const path = `M 0 4 Q 10 0, 20 4 T 40 4 T 60 4 T ${width} 4`;
  return (
    <svg width={width} height="8" viewBox={`0 0 ${width} 8`} style={style}>
      <path d={path} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}

// Image placeholder — diagonal-striped box w/ label
function ImgPlaceholder({ width = '100%', height = 120, label = 'IMAGE', style = {}, seed = 1 }) {
  return (
    <div style={{ position: 'relative', width, height, ...style }}>
      <SketchBox width="100%" height={height} fill="transparent" seed={seed}>
        <svg width="100%" height="100%" style={{ position: 'absolute', inset: 0 }} preserveAspectRatio="none">
          <defs>
            <pattern id={`stripes-${seed}`} patternUnits="userSpaceOnUse" width="8" height="8" patternTransform="rotate(45)">
              <line x1="0" y1="0" x2="0" y2="8" stroke={WF.inkFaint} strokeWidth="0.6" />
            </pattern>
          </defs>
          <rect x="2" y="2" width="calc(100% - 4)" height="calc(100% - 4)" fill={`url(#stripes-${seed})`} opacity="0.5" />
        </svg>
        <div style={{
          position: 'absolute', inset: 0, display: 'flex',
          alignItems: 'center', justifyContent: 'center',
          fontFamily: WF.mono, fontSize: 10, color: WF.inkFaint,
          letterSpacing: 1,
        }}>{label}</div>
      </SketchBox>
    </div>
  );
}

// Fake text — horizontal lines representing copy
function FakeText({ lines = 3, width = '100%', lastWidth = '70%', style = {}, color = WF.inkSoft, lineHeight = 9, gap = 6 }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap, width, ...style }}>
      {Array.from({ length: lines }).map((_, i) => {
        const w = i === lines - 1 ? lastWidth : (85 + Math.sin(i * 3) * 10) + '%';
        return (
          <div key={i} style={{
            height: lineHeight * 0.4, width: w,
            background: color, opacity: 0.35, borderRadius: 2,
          }} />
        );
      })}
    </div>
  );
}

// Hand-written heading
function HandTitle({ children, size = 32, color = WF.ink, style = {} }) {
  return (
    <div style={{
      fontFamily: WF.display, fontSize: size, fontWeight: 700,
      color, lineHeight: 1, letterSpacing: 0.3, ...style,
    }}>{children}</div>
  );
}

// Hand-written label/body
function HandText({ children, size = 14, color = WF.inkSoft, style = {} }) {
  return (
    <div style={{
      fontFamily: WF.hand, fontSize: size, color, lineHeight: 1.4, ...style,
    }}>{children}</div>
  );
}

// Annotation arrow + note (margin annotation style)
function Annotation({ children, side = 'right', style = {} }) {
  return (
    <div style={{
      fontFamily: WF.display, fontSize: 18, color: WF.accent,
      lineHeight: 1.1, ...style,
    }}>
      {side === 'left' && <span style={{ marginRight: 6 }}>→</span>}
      {children}
      {side === 'right' && <span style={{ marginLeft: 6 }}>←</span>}
    </div>
  );
}

// Button placeholder
function SketchBtn({ children, primary = false, width = 120, height = 36, style = {} }) {
  return (
    <SketchBox
      width={width} height={height}
      fill={primary ? WF.ink : 'transparent'}
      stroke={WF.ink}
      strokeWidth={primary ? 0 : 1.5}
      seed={children?.length || 1}
      style={style}
    >
      <div style={{
        position: 'absolute', inset: 0, display: 'flex',
        alignItems: 'center', justifyContent: 'center',
        fontFamily: WF.hand, fontSize: 14, fontWeight: 600,
        color: primary ? WF.paper : WF.ink,
      }}>{children}</div>
    </SketchBox>
  );
}

// Avatar circle placeholder
function Avatar({ size = 80, label = 'OO' }) {
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      border: `1.5px solid ${WF.ink}`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: WF.display, fontSize: size * 0.4, color: WF.ink,
      background: WF.accentSoft,
    }}>{label}</div>
  );
}

// Tag/chip
function Tag({ children, accent = false }) {
  return (
    <div style={{
      display: 'inline-block',
      padding: '3px 10px',
      border: `1.2px solid ${accent ? WF.accent : WF.ink}`,
      borderRadius: 12,
      fontFamily: WF.hand, fontSize: 12,
      color: accent ? WF.accent : WF.ink,
      background: accent ? WF.accentSoft : 'transparent',
    }}>{children}</div>
  );
}

// Paper background for the wireframe artboard
function Paper({ width, height, children, style = {} }) {
  return (
    <div style={{
      width, height, background: WF.paper,
      position: 'relative', overflow: 'hidden',
      boxShadow: 'inset 0 0 0 1px rgba(0,0,0,0.05)',
      ...style,
    }}>
      {children}
    </div>
  );
}

Object.assign(window, {
  WF, SketchBox, SketchLine, Squiggle, ImgPlaceholder, FakeText,
  HandTitle, HandText, Annotation, SketchBtn, Avatar, Tag, Paper,
});
